import type { IBattleEntity, ProgramEntity, IBattleState, IMingmingState, IDeckState } from '../types';
import { initializeBattleEntity } from '../types';
import { GetProgramData } from './programRegistry';
import { GetMingmingData } from './mingmingRegistry';
import { applyDrivers } from './driverRegistry';
import { tagMirrorFoes } from './mirrorNames';
import { SeedStream, rollSeed } from '../core/SeedStream';
import { beginTurn } from '../battleReducer';

/**
 * Ticket 21: the `level` and `experience` parameters are gone. Every entity is built at
 * `CALIBRATION_LEVEL`, so there was nothing left for a caller to vary and leaving the parameters
 * in place would have been an invitation to re-introduce stat scaling.
 */
export function createMockEntity(
    name: string,
    mingmingId: string = 'fenrir',
    rng: SeedStream = new SeedStream(rollSeed())
): IBattleEntity {
    const definition = GetMingmingData(mingmingId);

    const instance: IMingmingState = {
        id: rng.nextId('mm'),
        definitionId: mingmingId,
        nickname: name,
        blueprintsCollected: 0,
        hpIV: rng.nextInt(0, 31),
        attackIV: rng.nextInt(0, 31),
        defenseIV: rng.nextInt(0, 31),
    };

    return initializeBattleEntity(instance, definition);
}

export function instantiateDeck(deckIds: string[], rng: SeedStream = new SeedStream(rollSeed())): ProgramEntity[] {
    return deckIds.map((id, index) => {
        if (!id) console.error(`instantiateDeck got undefined at index ${index} in deckIds:`, deckIds);
        return {
            id: rng.nextId('card'),
            dataId: id,
            // X-cost cards carry 0 here; their real price is resolved per play by
            // getEffectiveCardCost from the source's current Energy.
            currentCost: typeof GetProgramData(id).baseCost === 'number' ? (GetProgramData(id).baseCost as number) : 0,
            isPlayable: true
        };
    });
}

import { generateEncounter } from './EncounterGenerator';
import type { Element, EnemyCombatMode } from '../types';
import type { AiTier } from '../ai/TacticalAI';

export interface BattleOptions {
    /**
     * Seed for every random decision made while *creating* the battle: party
     * size, IVs, deck shuffles, opening draws, entity and card-instance ids.
     * Omit it and one is rolled here, then threaded the same way - so the
     * resulting battle is always reproducible from the seed it records.
     */
    readonly seed?: string;

    /**
     * How the enemy side fights, locked in at battle creation.
     * Defaults to 'MOVES' (telegraphed intents, no cards). Passing
     * 'CARDS' explicitly is the ONLY way to create card-playing enemies.
     */
    readonly enemyMode?: EnemyCombatMode;

    /**
     * Which grade of `TacticalAI` plays the enemy — steam-release ticket 60's enemy ladder.
     * Omitted means the process-wide default, which is what every battle outside a run gets.
     * See `IBattleState.enemyAiTier`.
     */
    readonly enemyAiTier?: AiTier;
    /**
     * TICKET 144 §2 — the beam width for this battle. Comes off the enemy ladder
     * (`IEnemyLoadout.beam`): all rungs beam 8 since ticket 166f. See `IBattleState.aiBeam`.
     */
    readonly aiBeam?: number;
}

/**
 * Everything a battle needs from outside itself — ticket 11.
 *
 * This replaces the `save: IPlayerSave` parameter `createBattleState` used to take, and the change
 * is not cosmetic. The old signature meant the battle factory read the *whole* save shape and
 * picked its branch out of it (`activeParty`, `roster`, `relics`, `gauntlet`, `activeDeck.cards`,
 * `cardInventory`) — six fields of a twelve-field blob, chosen by rules only this function knew.
 * With the ranch/run split there is no single object that holds all six any more, and inventing one
 * would have re-created `IPlayerSave` under a new name. So the caller resolves the questions
 * instead, and what arrives here is answers: a party, a deck, some drivers, some carried HP.
 *
 * `engine/run/battleSetup.ts` builds one of these from `(IRanchState, IRunState)`. The debug
 * scenario path bypasses this function entirely (`debug/scenarios/buildScenarioState.ts`).
 */
export interface IBattleSetup {
    /** The party, already resolved and ordered. */
    readonly party: ReadonlyArray<IMingmingState>;
    /** The deck as dataIds. The instance-id indirection is gone — a run deck holds dataIds. */
    readonly deck: ReadonlyArray<string>;
    /** Was `relics`. Applied to the player side and copied to `IBattleState.activeDrivers`. */
    readonly drivers: ReadonlyArray<string>;
    /**
     * TICKET 163d — each party member's patch, by member id, carried from `IRunState.patches`.
     *
     * Beside `drivers` rather than folded into `IMingmingState`, and the distinction is the one
     * `drivers` already makes: a Driver is a thing the RUN owns and applies to a body, and so is a
     * patch. `IMingmingState` is the individual in the save file, which outlives the run.
     */
    readonly patches?: Readonly<Record<string, ReadonlyArray<string>>>;
    /**
     * The ENEMY side's Drivers — ticket 68 build step 1. Applied to every enemy member by the same
     * `applyDrivers` the player's list goes through, so a Driver that works on one side works on
     * the other by construction.
     *
     * **Optional where `drivers` is required, and that asymmetry is honest rather than an
     * oversight.** Every fight has a player side and the run always has a (possibly empty) Driver
     * list to hand it; almost no fight has an enemy Driver — one gym's third fight and one grade of
     * elite carry one, and everything else in the game would be writing `enemyDrivers: []` to say
     * nothing. Absent and empty mean the same thing here and the code treats them identically.
     *
     * Not copied to `IBattleState.activeDrivers`: that field is the PLAYER's list, read by
     * `resolutionEngine` for `buffer_cache`, and mixing both sides into it would make a
     * side-agnostic lookup out of something every reader treats as side-specific.
     */
    readonly enemyDrivers?: ReadonlyArray<string>;
    /**
     * HP carried between gauntlet fights, by member id. Empty outside a gauntlet.
     *
     * **A 0 in here is not the same as an absent key**, and ticket 18 depends on the difference: an
     * absent key means "this member was not carrying anything, build it at full HP", while a 0 means
     * "this member is DOWN and stays down into this fight" (`IGauntletProgress.downedMemberIds`
     * names the same members). The carry below therefore tests `!== undefined` rather than
     * truthiness — `if (carriedHp)` would silently full-heal every fainted member at the start of
     * every gauntlet fight, which is the exact bug the three-fight chain exists to avoid.
     */
    readonly persistedHp: Readonly<Record<string, number>>;
    /**
     * A pre-rolled enemy side — ticket 11, part 2. Set for every fight started from a region node;
     * absent everywhere else.
     *
     * **Why the enemies arrive built rather than being generated here.** A run encounter is decided
     * by the node's kind, the biome's element, the biome's *depth* and the node's visit count
     * (`engine/run/encounter.ts`), and only the second of those four is anything this function could
     * be handed as a parameter. Threading the other three in would have meant teaching the battle
     * factory what a region graph is, which is the same mistake `IBattleSetup` exists to undo. So
     * the run rolls its own encounter and passes the answer, exactly as it passes its party and its
     * deck.
     *
     * Structurally typed rather than importing `IRunEncounter`, so the engine's lowest layer keeps
     * no import edge to the run loop.
     */
    readonly encounter?: {
        readonly enemyParty: ReadonlyArray<IBattleEntity>;
        readonly enemyDeckIds: ReadonlyArray<string>;
        /** Ticket 68: the fight's own enemy Drivers, copied up to `enemyDrivers` by `buildBattleSetup`. */
        readonly enemyDrivers?: ReadonlyArray<string>;
    } | null;
}

export function createBattleState(
    setup: IBattleSetup,
    enemyIds: string[],
    sectorElement?: Element,
    options?: BattleOptions
): IBattleState {
    const enemyMode: EnemyCombatMode = options?.enemyMode ?? 'MOVES';

    // One seed, threaded through every random decision below. When no seed is
    // supplied we roll exactly once - the only non-deterministic call left on
    // the creation path.
    const battleSeed: string = options?.seed ?? rollSeed();
    const rng = new SeedStream(battleSeed);
    const playerPartyMembers = setup.party;

    if (playerPartyMembers.length === 0) throw new Error("No party members in the battle setup!");

    const playerParty = playerPartyMembers.map(mm => {
        let entity = initializeBattleEntity(mm, GetMingmingData(mm.definitionId));

        // Gauntlet persistence (ticket 18, and Milestone 8.3 before it). `persistedHp` is empty
        // outside a gauntlet (`IGauntletProgress.persistedHp` is the only HP store in `IRunState`),
        // so this needs no gauntlet check of its own — which is also why a full heal between
        // ordinary nodes is true by construction rather than by a rule someone has to remember.
        //
        // `!== undefined`, never a truthiness test: 0 is a downed member and must build at 0. See
        // `IBattleSetup.persistedHp`.
        const carriedHp = setup.persistedHp[mm.id];
        if (carriedHp !== undefined) {
            entity = {
                ...entity,
                currentHp: carriedHp
            };
        }

        // Milestone 8.4: Driver (was: relic) application.
        //
        // Ticket 68 moved the three stat effects that used to be spelled out here into
        // `data/driverRegistry.applyDrivers`, so that the enemy side below can go through the
        // identical path rather than a copy of it. Nothing about the player's Drivers changed.
        entity = applyDrivers(entity, setup.drivers);

        /*
         * TICKET 163d — the run's patch for THIS member, onto the entity that fights.
         *
         * A plain field rather than an `applyPatches` the way Drivers get an `applyDrivers`,
         * because a Driver CHANGES STATS at setup and a patch changes nothing until a hook
         * resolves: `entityHooksFor` reads `entity.patches` and rebuilds the firmware's hooks for
         * this body. So all setup has to do is carry it across.
         */
        const fitted = setup.patches?.[mm.id];
        if (fitted && fitted.length > 0) entity = { ...entity, patches: [...fitted] };

        return entity;
    });

    let enemyParty: IBattleEntity[] = [];
    let enemyDeckIds: string[] = [];

    // Ticket 11: a region node brings its own enemies. This branch is first because it is the only
    // one with the full picture — the node's kind, depth and visit count all went into the roll —
    // so anything below it would be second-guessing an answer that has already been given.
    if (setup.encounter) {
        enemyParty = [...setup.encounter.enemyParty];
        enemyDeckIds = [...setup.encounter.enemyDeckIds];
    /*
     * TICKET 18 DELETED THE GYM-TIER BRANCH THAT USED TO SIT HERE.
     *
     * It was pre-run-loop, and every one of its parts contradicted a ruling that has landed since:
     *
     *   - a hardcoded `synergyMap` paired each gym element with a second one (Fire+Earth,
     *     Water+Nature), which ticket 05's mono-element biomes and pure counter cycle replaced;
     *   - tier 1 rolled ONE OR TWO enemies, where ticket 18 rules the gauntlet "always full 3v3
     *     curated";
     *   - tier 3 built a "Sector Warden" at `maxHp * 1.5` with three hardcoded moves, i.e. difficulty
     *     as a bigger number and as bespoke content in the battle factory — ticket 21 froze stat
     *     scaling and `vision.md` rules difficulty as team design ("never bigger numbers");
     *   - and it drew its species from `getSectorSpecies(gymElement)`, so the boss had nothing to do
     *     with the three biomes the player had just walked, which is precisely the connection ticket
     *     18 exists to make.
     *
     * Its replacement is `engine/run/gauntlet.rollGauntletFight`, which arrives through
     * `setup.encounter` above like any other pre-rolled fight. The battle factory therefore has no
     * gauntlet branch at all any more, and `IBattleSetup` no longer carries a `gauntlet` field: what
     * a gauntlet still needs from this function is `persistedHp`, and that is one lookup, not a mode.
     */
    } else if (sectorElement) {
        // Epic 8: Logic transition to Encounter Generator
        const encounter = generateEncounter({
            sectorElement,
            playerParty,
            seed: rng.fork('encounter_sector')
        });
        enemyParty = encounter.enemyParty;
        enemyDeckIds = encounter.enemyDeckIds;
    } else {
        // Fallback or fixed encounters (e.g. initial dev test)
        enemyParty = enemyIds.map(enemyId => createMockEntity('Wild ' + GetMingmingData(enemyId).name, enemyId, rng));

        // Use the old archetype logic for fixed encounters if needed, or simple direct IDs
        enemyDeckIds = enemyIds.map(enemyId => {
            const def = GetMingmingData(enemyId);
            let archetype: 'FENRIR' | 'KRAKEN' | 'RATATOSKR' = 'FENRIR';
            if (def.primaryElement === 'Water') archetype = 'KRAKEN';
            if (def.primaryElement === 'Nature') archetype = 'RATATOSKR';

            const lists = {
                FENRIR: { daemon: 'core_overclock_daemon', cards: ['fire_poke', 'fire_punch_v2', 'cinder_slash', 'brute_force', 'fury_strike', 'scorch'] },
                KRAKEN: { daemon: 'feedback_loop_daemon', cards: ['water_slap', 'whirlpool_v2', 'surge_protection', 'poison_injection', 'acid_splash', 'toxic_surge', 'corrosive_bolt', 'contagion'] },
                RATATOSKR: { daemon: 'fertile_ground_daemon', cards: ['water_slap', 'nettle_sting', 'thistle_barrage', 'seed_bomb_v2', 'soothe', 'pollen_cloud', 'crippling_vine'] }
            };
            const list = lists[archetype];
            return [list.daemon, ...list.cards.slice(0, 9)];
        }).flat();
    }

    // Epic 2/22/2026: Disable OS on enemies as they use intents now.
    //
    // Ticket 11: a pre-rolled run encounter is exempt, because for it the OS is not an oversight to
    // be cleaned up but half of ticket 08's ruled kit fraction — a biome-0 enemy runs no firmware
    // and a biome-1 enemy runs its own, and `engine/run/encounter.ts` has already said which. A
    // blanket strip here would silently delete that rule and make every depth field the same enemy.
    //
    // TICKET 72: the `boss_relic_*` exemption that used to sit here is gone with the relics — every
    // gym is authored now, and an authored boss arrives through `setup.encounter` carrying its
    // members' own tuned OSes. What remains is the plain strip: an enemy built HERE (the debug and
    // legacy paths) runs no firmware unless the encounter said so.
    if (!setup.encounter) {
        enemyParty = enemyParty.map(e => ({ ...e, activeOS: undefined }));
    }

    /*
     * TICKET 68 — the enemy side's Drivers, the mirror of the player's above.
     *
     * Applied AFTER the OS strip on purpose. A Driver is additive: it attaches hook ids and never
     * touches `activeOS`, so running it before the strip would be harmless but would read as though
     * the two interacted. Applied last, the order says what is true — the enemy's firmware is
     * settled first, and the Driver goes on top of whatever it turned out to be.
     *
     * Empty for every fight but Emberfall's third and the elites guarding its approach, so this is
     * a no-op on the overwhelming majority of battles and allocates nothing when the list is empty.
     */
    const enemyDrivers = setup.enemyDrivers ?? [];
    if (enemyDrivers.length > 0) {
        enemyParty = enemyParty.map(e => applyDrivers(e, enemyDrivers));
    }

    // A foe of the same species as a party member is named apart (`Kraken (foe)`), so the combat log
    // and the board can tell a mirror fight's two units apart. Last, so nothing above sees the tag.
    enemyParty = tagMirrorFoes(playerParty, enemyParty);

    // --- SHARED DECK INITIALIZATION ---

    // The archetype fallback below is a pre-run-loop leftover: it invents a deck for a party that
    // arrived without one. **Ticket 12 should delete it.** A run always has a deck now — `createRun`
    // mints 8 cards per starting member from ticket 08's `startKit` tags and the run builds from
    // there — so the only callers that can still hit this branch are tests and debug paths that
    // hand over an empty `setup.deck`. Removing it today would turn those into throws in the same
    // commit that moves the shape, which is one change too many.
    const FALLBACK_ARCHETYPES = ['FENRIR', 'KRAKEN', 'RATATOSKR'] as const;
    type FallbackArchetype = typeof FALLBACK_ARCHETYPES[number];
    const isFallbackArchetype = (id: string): id is FallbackArchetype =>
        (FALLBACK_ARCHETYPES as readonly string[]).includes(id);

    const getArchetypeDeck = (archetype: FallbackArchetype): string[] => {
        const lists = {
            FENRIR: {
                daemon: 'core_overclock_daemon',
                cards: ['fire_poke', 'fire_punch_v2', 'fire_punch_v2', 'cinder_slash', 'cinder_slash', 'brute_force', 'fury_strike', 'scorch', 'ignite', 'ignite', 'strength_burst']
            },
            KRAKEN: {
                daemon: 'feedback_loop_daemon',
                cards: ['water_slap', 'water_slap', 'whirlpool_v2', 'whirlpool_v2', 'surge_protection', 'surge_protection', 'poison_injection', 'acid_splash', 'toxic_surge', 'corrosive_bolt', 'contagion']
            },
            RATATOSKR: {
                daemon: 'fertile_ground_daemon',
                cards: ['water_slap', 'water_slap', 'nettle_sting', 'nettle_sting', 'thistle_barrage', 'thistle_barrage', 'seed_bomb_v2', 'soothe', 'pollen_cloud', 'pollen_cloud', 'crippling_vine']
            }
        };

        const list = lists[archetype];
        const shuffled = rng.shuffle(list.cards);
        return [list.daemon, ...shuffled.slice(0, 9)];
    };

    const playerArchetype = playerParty[0].definitionId.toUpperCase();

    let playerDeckIds: string[] = [];
    if (setup.deck.length > 0) {
        // Already dataIds — the run deck holds them directly, so the instance-id lookup that used
        // to resolve `activeDeck.cards` against `cardInventory` has nothing left to do.
        playerDeckIds = [...setup.deck];
    } else {
        playerDeckIds = getArchetypeDeck(isFallbackArchetype(playerArchetype) ? playerArchetype : 'FENRIR');
    }

    const pDeckCardsRaw = instantiateDeck(playerDeckIds, rng);
    const pDeckCards = rng.shuffle(pDeckCardsRaw);

    const eDeckCardsRaw = instantiateDeck(enemyDeckIds, rng);
    const eDeckCards = rng.shuffle(eDeckCardsRaw);

    // Ticket 164c: opening hand is drawn by beginTurn, not by hand here.
    const pInitialDeck: IDeckState = {
        ownerId: 'PLAYER',
        deck: [],
        drawpile: pDeckCards,
        hand: [],
        discard: [],
        exhaust: []
    };

    // A battle with no enemies is unwinnable-by-definition and renders a ghost
    // arena (empty enemy column, instant hollow victory). Fail loudly instead.
    if (enemyParty.length === 0) {
        throw new Error(`[createBattleState] No enemies generated (encounter: ${setup.encounter ? setup.encounter.enemyParty.length : 'none'}, sector: ${sectorElement}, enemyIds: ${JSON.stringify(enemyIds)})`);
    }

    const eDeckState: IDeckState = {
        ownerId: 'ENEMY',
        deck: [],
        // Move users get no drawpile at all; card users get their shuffled pile and an EMPTY hand.
        drawpile: enemyMode === 'CARDS' ? eDeckCards : [],
        hand: [],
        discard: [],
        exhaust: []
    };

    const rawState: IBattleState = {
        // sessionId lives inside IBattleState, so a wall-clock value would
        // break every replay diff on its own. Derive it from the seed instead.
        sessionId: 'battle_' + battleSeed,
        seed: rng.seed,
        turn: 1,
        phase: 'ACTION',
        activeSide: 'PLAYER',
        logs: [],
        osLogs: [],
        procs: [],
        playerParty: playerParty,
        enemyParty: enemyParty,
        playerDeck: pInitialDeck,
        enemyDeck: eDeckState,
        cardsPlayedThisTurn: 0,
        cardsDrawnThisTurn: 0,
        nonNaturalCardsDrawnThisTurn: 0,
        lastProgramPlayed: null,
        elementPlays: {
            'Fire': 0, 'Water': 0, 'Earth': 0, 'Air': 0, 'Nature': 0,
            'Ice': 0, 'Light': 0, 'Dark': 0, 'None': 0
        },
        counters: {},
        activeDrivers: [...setup.drivers],
        enemyMode,
        // Ticket 144 §2: unset means "take the process default", which is BEAMLESS. The game
        // supplies a width per fight off the enemy ladder; a harness that wants one asks by name.
        aiBeam: options?.aiBeam,
        // Undefined rather than a default, deliberately: `TacticalAI.tierFor` reads "unset" as
        // "take the process default", and writing a concrete 'full' here would override the
        // AI_GREEDY / AI_LITE environment the balance corpus runs under.
        enemyAiTier: options?.enemyAiTier
    };

    return beginTurn(rawState, 'PLAYER', 1);
}
